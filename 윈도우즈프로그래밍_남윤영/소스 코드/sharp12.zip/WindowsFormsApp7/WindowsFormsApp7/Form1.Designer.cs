﻿
namespace WindowsFormsApp7
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.sik = new System.Windows.Forms.TextBox();
            this.result = new System.Windows.Forms.TextBox();
            this.sin = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.CE = new System.Windows.Forms.Button();
            this.C = new System.Windows.Forms.Button();
            this.pm = new System.Windows.Forms.Button();
            this.root = new System.Windows.Forms.Button();
            this.zegop = new System.Windows.Forms.Button();
            this.divide = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.cos = new System.Windows.Forms.Button();
            this.bunsu = new System.Windows.Forms.Button();
            this.mul = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.tan = new System.Windows.Forms.Button();
            this.equl = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.npack = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.point = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.log = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // sik
            // 
            this.sik.Location = new System.Drawing.Point(12, 24);
            this.sik.Name = "sik";
            this.sik.Size = new System.Drawing.Size(376, 21);
            this.sik.TabIndex = 0;
            // 
            // result
            // 
            this.result.Location = new System.Drawing.Point(10, 51);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(378, 21);
            this.result.TabIndex = 1;
            // 
            // sin
            // 
            this.sin.Location = new System.Drawing.Point(10, 78);
            this.sin.Name = "sin";
            this.sin.Size = new System.Drawing.Size(58, 31);
            this.sin.TabIndex = 2;
            this.sin.Text = "sin";
            this.sin.UseVisualStyleBackColor = true;
            this.sin.Click += new System.EventHandler(this.button1_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(74, 78);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(58, 31);
            this.back.TabIndex = 3;
            this.back.Text = "<-";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // CE
            // 
            this.CE.Location = new System.Drawing.Point(138, 78);
            this.CE.Name = "CE";
            this.CE.Size = new System.Drawing.Size(58, 31);
            this.CE.TabIndex = 4;
            this.CE.Text = "CE";
            this.CE.UseVisualStyleBackColor = true;
            this.CE.Click += new System.EventHandler(this.CE_Click);
            // 
            // C
            // 
            this.C.Location = new System.Drawing.Point(202, 78);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(58, 31);
            this.C.TabIndex = 5;
            this.C.Text = "C";
            this.C.UseVisualStyleBackColor = true;
            this.C.Click += new System.EventHandler(this.C_Click);
            // 
            // pm
            // 
            this.pm.Location = new System.Drawing.Point(266, 78);
            this.pm.Name = "pm";
            this.pm.Size = new System.Drawing.Size(58, 31);
            this.pm.TabIndex = 6;
            this.pm.Text = "+-";
            this.pm.UseVisualStyleBackColor = true;
            this.pm.Click += new System.EventHandler(this.pm_Click);
            // 
            // root
            // 
            this.root.Location = new System.Drawing.Point(330, 78);
            this.root.Name = "root";
            this.root.Size = new System.Drawing.Size(58, 31);
            this.root.TabIndex = 7;
            this.root.Text = "_/";
            this.root.UseVisualStyleBackColor = true;
            this.root.Click += new System.EventHandler(this.root_Click);
            // 
            // zegop
            // 
            this.zegop.Location = new System.Drawing.Point(330, 115);
            this.zegop.Name = "zegop";
            this.zegop.Size = new System.Drawing.Size(58, 31);
            this.zegop.TabIndex = 13;
            this.zegop.Text = "x^2";
            this.zegop.UseVisualStyleBackColor = true;
            this.zegop.Click += new System.EventHandler(this.zegop_Click);
            // 
            // divide
            // 
            this.divide.Location = new System.Drawing.Point(266, 115);
            this.divide.Name = "divide";
            this.divide.Size = new System.Drawing.Size(58, 31);
            this.divide.TabIndex = 12;
            this.divide.Text = "/";
            this.divide.UseVisualStyleBackColor = true;
            this.divide.Click += new System.EventHandler(this.divide_Click);
            // 
            // nine
            // 
            this.nine.Location = new System.Drawing.Point(202, 115);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(58, 31);
            this.nine.TabIndex = 11;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = true;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.Location = new System.Drawing.Point(138, 115);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(58, 31);
            this.eight.TabIndex = 10;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = true;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // seven
            // 
            this.seven.Location = new System.Drawing.Point(74, 115);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(58, 31);
            this.seven.TabIndex = 9;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = true;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // cos
            // 
            this.cos.Location = new System.Drawing.Point(10, 115);
            this.cos.Name = "cos";
            this.cos.Size = new System.Drawing.Size(58, 31);
            this.cos.TabIndex = 8;
            this.cos.Text = "cos";
            this.cos.UseVisualStyleBackColor = true;
            this.cos.Click += new System.EventHandler(this.cos_Click);
            // 
            // bunsu
            // 
            this.bunsu.Location = new System.Drawing.Point(330, 152);
            this.bunsu.Name = "bunsu";
            this.bunsu.Size = new System.Drawing.Size(58, 31);
            this.bunsu.TabIndex = 19;
            this.bunsu.Text = "1/x";
            this.bunsu.UseVisualStyleBackColor = true;
            this.bunsu.Click += new System.EventHandler(this.bunsu_Click);
            // 
            // mul
            // 
            this.mul.Location = new System.Drawing.Point(266, 152);
            this.mul.Name = "mul";
            this.mul.Size = new System.Drawing.Size(58, 31);
            this.mul.TabIndex = 18;
            this.mul.Text = "*";
            this.mul.UseVisualStyleBackColor = true;
            this.mul.Click += new System.EventHandler(this.mul_Click);
            // 
            // six
            // 
            this.six.Location = new System.Drawing.Point(202, 152);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(58, 31);
            this.six.TabIndex = 17;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = true;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // five
            // 
            this.five.Location = new System.Drawing.Point(138, 152);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(58, 31);
            this.five.TabIndex = 16;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.Location = new System.Drawing.Point(74, 152);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(58, 31);
            this.four.TabIndex = 15;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // tan
            // 
            this.tan.Location = new System.Drawing.Point(10, 152);
            this.tan.Name = "tan";
            this.tan.Size = new System.Drawing.Size(58, 31);
            this.tan.TabIndex = 14;
            this.tan.Text = "tan";
            this.tan.UseVisualStyleBackColor = true;
            this.tan.Click += new System.EventHandler(this.tan_Click);
            // 
            // equl
            // 
            this.equl.Location = new System.Drawing.Point(330, 189);
            this.equl.Name = "equl";
            this.equl.Size = new System.Drawing.Size(58, 68);
            this.equl.TabIndex = 25;
            this.equl.Text = "=";
            this.equl.UseVisualStyleBackColor = true;
            this.equl.Click += new System.EventHandler(this.equl_Click);
            // 
            // minus
            // 
            this.minus.Location = new System.Drawing.Point(266, 189);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(58, 31);
            this.minus.TabIndex = 24;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // three
            // 
            this.three.Location = new System.Drawing.Point(202, 189);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(58, 31);
            this.three.TabIndex = 23;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // two
            // 
            this.two.Location = new System.Drawing.Point(138, 189);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(58, 31);
            this.two.TabIndex = 22;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // one
            // 
            this.one.Location = new System.Drawing.Point(74, 189);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(58, 31);
            this.one.TabIndex = 21;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // npack
            // 
            this.npack.Location = new System.Drawing.Point(10, 189);
            this.npack.Name = "npack";
            this.npack.Size = new System.Drawing.Size(58, 31);
            this.npack.TabIndex = 20;
            this.npack.Text = "n!";
            this.npack.UseVisualStyleBackColor = true;
            this.npack.Click += new System.EventHandler(this.npack_Click);
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(266, 226);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(58, 31);
            this.plus.TabIndex = 30;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // point
            // 
            this.point.Location = new System.Drawing.Point(202, 226);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(58, 31);
            this.point.TabIndex = 29;
            this.point.Text = ".";
            this.point.UseVisualStyleBackColor = true;
            this.point.Click += new System.EventHandler(this.point_Click);
            // 
            // zero
            // 
            this.zero.Location = new System.Drawing.Point(74, 226);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(122, 31);
            this.zero.TabIndex = 27;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = true;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // log
            // 
            this.log.Location = new System.Drawing.Point(10, 226);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(58, 31);
            this.log.TabIndex = 26;
            this.log.Text = "log";
            this.log.UseVisualStyleBackColor = true;
            this.log.Click += new System.EventHandler(this.log_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 281);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.point);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.log);
            this.Controls.Add(this.equl);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.three);
            this.Controls.Add(this.two);
            this.Controls.Add(this.one);
            this.Controls.Add(this.npack);
            this.Controls.Add(this.bunsu);
            this.Controls.Add(this.mul);
            this.Controls.Add(this.six);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.tan);
            this.Controls.Add(this.zegop);
            this.Controls.Add(this.divide);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.cos);
            this.Controls.Add(this.root);
            this.Controls.Add(this.pm);
            this.Controls.Add(this.C);
            this.Controls.Add(this.CE);
            this.Controls.Add(this.back);
            this.Controls.Add(this.sin);
            this.Controls.Add(this.result);
            this.Controls.Add(this.sik);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox sik;
        private System.Windows.Forms.TextBox result;
        private System.Windows.Forms.Button sin;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button CE;
        private System.Windows.Forms.Button C;
        private System.Windows.Forms.Button pm;
        private System.Windows.Forms.Button root;
        private System.Windows.Forms.Button zegop;
        private System.Windows.Forms.Button divide;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button cos;
        private System.Windows.Forms.Button bunsu;
        private System.Windows.Forms.Button mul;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button tan;
        private System.Windows.Forms.Button equl;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button npack;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button point;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button log;
    }
}

