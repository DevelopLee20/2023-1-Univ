﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public static class Global
        {
            public static double temp = 0;
            public static string op;
            public static bool yestemp;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sik.Text += "sin";
            try
            {
                Global.temp = Double.Parse(sik.Text);
            }
            catch(Exception ex)
            {
                Global.temp = 1;
            }
            Global.op = "sin";
            Global.yestemp = true;
        }

        private void CE_Click(object sender, EventArgs e)
        {
            result.Text = "";
        }

        private void C_Click(object sender, EventArgs e)
        {
            sik.Text = "";
            result.Text = "";
        }

        private void back_Click(object sender, EventArgs e)
        {
            sik.Text = sik.Text.Substring(0, sik.Text.Length - 1) + "";
        }

        private void seven_Click(object sender, EventArgs e)
        {
            if(Global.yestemp)
            {
                sik.Text = "7";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "7";
            }
        }

        private void eight_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "8";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "8";
            }
        }

        private void nine_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "9";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "9";
            }
        }

        private void four_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "4";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "4";
            }
        }

        private void five_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "5";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "5";
            }
        }

        private void six_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "6";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "6";
            }
        }

        private void one_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "1";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "1";
            }
        }

        private void two_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "2";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "2";
            }
        }

        private void three_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "3";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "3";
            }
        }

        private void zero_Click(object sender, EventArgs e)
        {
            if (Global.yestemp)
            {
                sik.Text = "0";
                Global.yestemp = false;
            }
            else
            {
                sik.Text += "0";
            }
        }

        private void plus_Click(object sender, EventArgs e)
        {
            if (sik.Text.Contains("/"))
            {
                double one = Double.Parse(sik.Text.Split('/')[0]);
                double two = Double.Parse(sik.Text.Split('/')[1]);
                Global.temp = one / two;
            }
            else if (sik.Text.Contains("^"))
            {
                double one = Double.Parse(sik.Text.Split('^')[0]);
                Global.temp = one * one;
            }
            else
            {
                Global.temp = Double.Parse(sik.Text);
            }
            Global.op = "+";
            Global.yestemp = true;
        }

        private void minus_Click(object sender, EventArgs e)
        {
            if (sik.Text.Contains("/"))
            {
                double one = Double.Parse(sik.Text.Split('/')[0]);
                double two = Double.Parse(sik.Text.Split('/')[1]);
                Global.temp = one / two;
            }
            else if (sik.Text.Contains("^"))
            {
                double one = Double.Parse(sik.Text.Split('^')[0]);
                Global.temp = one * one;
            }
            else
            {
                Global.temp = Double.Parse(sik.Text);
            }
            Global.op = "-";
            Global.yestemp = true;
        }

        private void mul_Click(object sender, EventArgs e)
        {
            if (sik.Text.Contains("/"))
            {
                double one = Double.Parse(sik.Text.Split('/')[0]);
                double two = Double.Parse(sik.Text.Split('/')[1]);
                Global.temp = one / two;
            }
            else if (sik.Text.Contains("^"))
            {
                double one = Double.Parse(sik.Text.Split('^')[0]);
                Global.temp = one * one;
            }
            else
            {
                Global.temp = Double.Parse(sik.Text);
            }
            Global.op = "*";
            Global.yestemp = true;
        }

        private void divide_Click(object sender, EventArgs e)
        {
            if (sik.Text.Contains("/"))
            {
                double one = Double.Parse(sik.Text.Split('/')[0]);
                double two = Double.Parse(sik.Text.Split('/')[1]);
                Global.temp = one / two;
            }
            else if (sik.Text.Contains("^"))
            {
                double one = Double.Parse(sik.Text.Split('^')[0]);
                Global.temp = one * one;
            }
            else
            {
                Global.temp = Double.Parse(sik.Text);
            }
            Global.op = "/";
            Global.yestemp = true;
        }

        private void bunsu_Click(object sender, EventArgs e)
        {
            sik.Text += "1/";
        }

        private void zegop_Click(object sender, EventArgs e)
        {
            sik.Text += "^2";
        }

        private void root_Click(object sender, EventArgs e)
        {
            sik.Text += "/-";
            try
            {
                Global.temp = Double.Parse(sik.Text);
            }
            catch (Exception ex)
            {
                Global.temp = 1;
            }
            Global.op = "root";
            Global.yestemp = true;
        }

        private void pm_Click(object sender, EventArgs e)
        {
            char check = sik.Text.FirstOrDefault();

            if(check == '-')
            {
                sik.Text = sik.Text.Substring(1);
            }
            else
            {
                sik.Text = "-" + sik.Text;
            }
        }

        private void point_Click(object sender, EventArgs e)
        {
            if (sik.Text != "")
            {
                sik.Text += ".";
            }
        }

        private void log_Click(object sender, EventArgs e)
        {
            sik.Text += "log";
            try
            {
                Global.temp = Double.Parse(sik.Text);
            }
            catch (Exception ex)
            {
                Global.temp = 1;
            }
            Global.op = "log";
            Global.yestemp = true;
        }

        private void npack_Click(object sender, EventArgs e)
        {
            sik.Text += "!";
            try
            {
                Global.temp = Double.Parse(sik.Text);
            }
            catch (Exception ex)
            {
                Global.temp = 1;
            }
            Global.op = "!";
            Global.yestemp = true;
        }

        private void tan_Click(object sender, EventArgs e)
        {
            sik.Text += "tan";
            try
            {
                Global.temp = Double.Parse(sik.Text);
            }
            catch (Exception ex)
            {
                Global.temp = 1;
            }
            Global.op = "tan";
            Global.yestemp = true;
        }

        private void cos_Click(object sender, EventArgs e)
        {
            sik.Text += "cos";
            try
            {
                Global.temp = Double.Parse(sik.Text);
            }
            catch (Exception ex)
            {
                Global.temp = 1;
            }
            Global.op = "cos";
            Global.yestemp = true;
        }

        private void equl_Click(object sender, EventArgs e)
        {
            double temp;

            try
            {
                temp = Double.Parse(sik.Text);
            }
            catch(Exception ex)
            {
                temp = 1;
            }

            if(Global.op == "+")
            {
                result.Text = (Global.temp + temp).ToString();
            }

            else if(Global.op == "-")
            {
                result.Text = (Global.temp - temp).ToString();
            }

            else if (Global.op == "*")
            {
                result.Text = (Global.temp * temp).ToString();
            }

            else if (Global.op == "/")
            {
                result.Text = (Global.temp / temp).ToString();
            }

            else if (Global.op == "sin")
            {
                result.Text = (Global.temp * Math.Sin(temp)).ToString();
            }

            else if (Global.op == "cos")
            {
                result.Text = (Global.temp * Math.Cos(temp)).ToString();
            }

            else if (Global.op == "tan")
            {
                result.Text = (Global.temp * Math.Tan(temp)).ToString();
            }

            else if (Global.op == "!")
            {
                int tem = 1;
                for(int i=(int)Global.temp; i>=2; i--)
                {
                    tem *= i;
                }
                result.Text = (tem).ToString();
            }

            else if (Global.op == "log")
            {
                result.Text = (Global.temp * Math.Log(temp)).ToString();
            }

            else if (Global.op == "root")
            {
                result.Text = (Global.temp * Math.Sqrt(temp)).ToString();
            }

            sik.Text = "";
        }
    }
}
