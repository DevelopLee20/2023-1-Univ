﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("열기");
        }

        private void 저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("닫기");
        }

        private void 끝내기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 메모장정보ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void 파일FToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void 도움말HToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 개발자정보ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("개발자: LeeInGyu\n이메일: developlee20@gmail.com");
        }
    }
}
