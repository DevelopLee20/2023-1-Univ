#ifndef _BASE_HEADER_
#define _BESE_HEADER_
#include <stdio.h>
#include <stdlib.h>
#define TRUE 1
#define FALSE 0
typedef int BOOL;
typedef char BYTE;
#endif